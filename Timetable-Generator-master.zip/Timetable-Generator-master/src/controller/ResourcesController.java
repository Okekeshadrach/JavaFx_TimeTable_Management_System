package controller;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javax.swing.JOptionPane;
import model.DbConnection;
import model.Room;
import model.StudentsGroup;

public class ResourcesController implements Initializable {

    @FXML
    private CheckBox saturdayCheckBox;
    @FXML
    private CheckBox fridayCheckBox;
    @FXML
    private CheckBox mondayCheckBox;
    @FXML
    private CheckBox tuesdayCheckBox;
    @FXML
    private CheckBox wednesdayCheckBox;
    @FXML
    private CheckBox thursdayCheckBox;

    @FXML
    private TableView<Room> roomTable = new TableView<>();
    @FXML
    private TableColumn<Room, String> roomIDCol;
    @FXML
    private TableColumn<Room, String> roomNameCol;

    @FXML
    private TableView<StudentsGroup> groupTable = new TableView<>();
    @FXML
    private TableColumn<StudentsGroup, Integer> groupIDCol;
    @FXML
    private TableColumn<StudentsGroup, String> groupNameCol;

    @FXML
    private TextField periodsCount;

    @FXML
    private TextField newRoomName;

    @FXML
    private TextField newGroupName;
    int ID;

    public ResourcesController() {

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        System.out.println("initilaize");
        roomIDCol.setCellValueFactory(new PropertyValueFactory<>("ID"));
        roomNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

        roomTable.setItems(PaneNavigator.getMainApp().getRoomData().sorted());

        groupIDCol.setCellValueFactory(new PropertyValueFactory<>("ID"));
        groupNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

        groupTable.setItems(PaneNavigator.getMainApp().getGroupData());

        HashMap<String, Boolean> workingDaysMap = PaneNavigator.getMainApp().getWorkingDays();
        mondayCheckBox.setSelected(workingDaysMap.get("monday"));
        tuesdayCheckBox.setSelected(workingDaysMap.get("tuesday"));
        wednesdayCheckBox.setSelected(workingDaysMap.get("wednesday"));
        thursdayCheckBox.setSelected(workingDaysMap.get("thursday"));
        fridayCheckBox.setSelected(workingDaysMap.get("friday"));
        saturdayCheckBox.setSelected(workingDaysMap.get("saturday"));
        periodsCount.setText(String.valueOf(PaneNavigator.getMainApp().getPeriodsCount()));

    }

    @FXML
    private void handleDeleteRoom() {
        int selectedIndex = roomTable.getSelectionModel().getSelectedIndex();

        if (selectedIndex >= 0) {
            Connection dbconn = DbConnection.DbConnection();
            String sql = "DELETE FROM `classroom` WHERE ID = ?";

            try {
                PreparedStatement pst = (PreparedStatement) dbconn.prepareStatement(sql);
                pst.setInt(1, selectedIndex);
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.initOwner(PaneNavigator.getMainApp().getPrimaryStage());
                alert.setTitle("You Are About to Delete A Classroom");
                alert.setHeaderText("Are You Sure You Want to Delete");
                alert.setContentText("Click Ok to Delete");
                pst.execute();

                alert.showAndWait();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex);

            }
            roomTable.getItems().remove(selectedIndex);
            PaneNavigator.getMainApp().getClassesData().clear();
        } else {
            // Nothing selected.
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initOwner(PaneNavigator.getMainApp().getPrimaryStage());
            alert.setTitle("No Selection");
            alert.setHeaderText("No Room Selected");
            alert.setContentText("Please select a room in the table.");

            alert.showAndWait();
        }
    }

    @FXML
    private void handleDeleteGroup() {
        int selectedIndex = groupTable.getSelectionModel().getSelectedIndex();

        if (selectedIndex >= 0) {
            Connection dbconn = DbConnection.DbConnection();
            String sql = "DELETE FROM `year` WHERE ID = ?";

            try {
                PreparedStatement pst = (PreparedStatement) dbconn.prepareStatement(sql);
                pst.setInt(1, selectedIndex);
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.initOwner(PaneNavigator.getMainApp().getPrimaryStage());
                alert.setTitle("You Are About to Delete A Year!!!!");
                alert.setHeaderText("Are You Sure You Want to Delete");
                alert.setContentText("Click Ok to Delete");
                pst.execute();

                alert.showAndWait();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex);

            }
            groupTable.getItems().remove(selectedIndex);
            PaneNavigator.getMainApp().getClassesData().clear();
        } else {
            // Nothing selected.
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initOwner(PaneNavigator.getMainApp().getPrimaryStage());
            alert.setTitle("No Selection");
            alert.setHeaderText("No Group Selected");
            alert.setContentText("Please select a group in the table.");

            alert.showAndWait();
        }
    }

    private boolean roomNameIsValid(String roomName) {
        return true;
    }

    private boolean groupNameIsValid(String groupName) {
        return true;
    }

    @FXML
    private void handleNewRoom() {

        String roomName = newRoomName.getText();
        if (roomName.isEmpty()) {
            JOptionPane.showMessageDialog(null, "new classroom field is empty \nCannot insert at this time until the field is filled", "Warning", JOptionPane.WARNING_MESSAGE);
        } else if (roomNameIsValid(roomName)) {
            Connection dbcon = DbConnection.DbConnection();
            if (dbcon != null) {

                try {
                    PreparedStatement st = (PreparedStatement) dbcon.prepareStatement("INSERT INTO `classroom` (`ID`, `ClassRoom_Name`) VALUES (NULL, ?)");

                    st.setString(1, roomName);

                    int res = st.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Class Added", "Successfull", JOptionPane.INFORMATION_MESSAGE);

                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, ex);
                }
            } else {
                System.out.println("Why All This!!!!!");
            }
            PaneNavigator.getMainApp().getRoomData().add(new Room(ID, roomName));
        }
    }

    @FXML
    private void handleNewGroup() {
        String groupName = newGroupName.getText();
        if (groupNameIsValid(groupName)) {
            Connection dbcon = DbConnection.DbConnection();
            if (dbcon != null) {
                try {
                    PreparedStatement st = (PreparedStatement) dbcon.prepareStatement("INSERT INTO `year` (`ID`, `Year`) VALUES (NULL, ?);");
                    st.setString(1, groupName);
                    int res = st.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Year Added", "Successfull", JOptionPane.INFORMATION_MESSAGE);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, ex);
                }
            } else {
                System.out.println("Why All This!!!!!");
            }
            PaneNavigator.getMainApp().getGroupData().add(new StudentsGroup(ID, groupName));
        }
    }

    @FXML
    private void goToCourses(ActionEvent event) {
        System.out.println("goToCourses");
        HashMap<String, Boolean> workingDaysMap = PaneNavigator.getMainApp().getWorkingDays();
        workingDaysMap.put("saturday", saturdayCheckBox.isSelected());
        workingDaysMap.put("sunday", fridayCheckBox.isSelected());
        workingDaysMap.put("monday", mondayCheckBox.isSelected());
        workingDaysMap.put("tuesday", tuesdayCheckBox.isSelected());
        workingDaysMap.put("wednesday", wednesdayCheckBox.isSelected());
        workingDaysMap.put("thursday", thursdayCheckBox.isSelected());
        PaneNavigator.getMainApp().setPeriodsCount(Integer.valueOf(periodsCount.getText()));
        PaneNavigator.loadPane(PaneNavigator.COURSES_PANE);
    }

    @FXML
    private void handleClearAll() {
        Connection dbcon = DbConnection.DbConnection();
        if (dbcon != null) {

            try {
                PreparedStatement st = (PreparedStatement) dbcon.prepareStatement("TRUNCATE `classroom`");
                PreparedStatement rst = (PreparedStatement) dbcon.prepareStatement("TRUNCATE `year`");

                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.initOwner(PaneNavigator.getMainApp().getPrimaryStage());
                alert.setTitle("You Are About to Delete All Resource Details!!!!");
                alert.setHeaderText("Are You Sure You Want to Delete ALL");
                alert.setContentText("Click Ok to Delete ALl");
                alert.showAndWait();


                int res = st.executeUpdate();
                int rs = rst.executeUpdate();
                JOptionPane.showMessageDialog(null, "Resources cleared succesfully", "Successfull", JOptionPane.INFORMATION_MESSAGE);

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(null,"Error occured while trying to delete instructors details","Error", JOptionPane.ERROR_MESSAGE);
        }
        roomTable.getItems().clear();
        groupTable.getItems().clear();
        PaneNavigator.getMainApp().getClassesData().clear();
    }

}
