package controller;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javax.swing.JOptionPane;
import model.Classes;
import model.Course;
import model.DbConnection;

public class CoursesController implements Initializable {
    @FXML
    private TableView<Course> courseTable = new TableView<>();
    @FXML
    private TableColumn<Course, String> courseCodeCol;
    @FXML
    private TableColumn<Course, String> courseNameCol;
    @FXML
    private TextField newCourseCode;
    @FXML
    private TextField newCourseName;


    public CoursesController(){

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        System.out.println("initilaize");
        courseNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        courseCodeCol.setCellValueFactory(new PropertyValueFactory<>("code"));
        courseTable.setItems(PaneNavigator.getMainApp().getCourseData());
    }

    @FXML
    private void handleDeleteCourse() {
        int selectedIndex = courseTable.getSelectionModel().getSelectedIndex();

        if (selectedIndex >= 0) {
            String sql = "DELETE FROM `course` WHERE ID = ?";
            Connection dbconn = DbConnection.DbConnection();
            try {
                PreparedStatement pst = (PreparedStatement) dbconn.prepareStatement(sql);
                pst.setInt(1, selectedIndex);
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.initOwner(PaneNavigator.getMainApp().getPrimaryStage());
                alert.setTitle("You Are About to Delete A Class Detail!!!!");
                alert.setHeaderText("Are You Sure You Want to Delete");
                alert.setContentText("Click Ok to Delete");

                alert.showAndWait();

                pst.execute();

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex);

            }

            courseTable.getItems().remove(selectedIndex);
            PaneNavigator.getMainApp().getClassesData().clear();

        } else {
            // Nothing selected.
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initOwner(PaneNavigator.getMainApp().getPrimaryStage());
            alert.setTitle("No Selection");
            alert.setHeaderText("No Course Selected");
            alert.setContentText("Please select a course in the table.");

            alert.showAndWait();
        }
    }

    private boolean courseDataIsValid(String courseCode, String courseName){
        return true;
    }

    @FXML
    private void handleNewCourse() {
        String courseCode = newCourseCode.getText();
        String courseName = newCourseName.getText();

        if(courseDataIsValid(courseCode,courseName)){
            Connection dbcon = DbConnection.DbConnection();
            if (dbcon != null) {
                try {
                    PreparedStatement st = (PreparedStatement) dbcon.prepareStatement("INSERT INTO `course` (`ID`, `CourseCode`,`CourseName`) VALUES (NULL,?,?);");
                    st.setString(1, courseCode);
                    st.setString(2, courseName);
                    int res = st.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Course Added", "Successfull", JOptionPane.INFORMATION_MESSAGE);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, ex);
                }
            } else {
                System.out.println("Why All This!!!!!");
            }
            PaneNavigator.getMainApp().getCourseData().add(new Course(courseName,courseCode));
        }
    }

    @FXML
    private void goToInstructors(ActionEvent event) {
        System.out.println("goToInstructors");
        PaneNavigator.loadPane(PaneNavigator.INSTRUCTORS_PANE);
    }

    @FXML
    private void handleClearAll() {
        Connection dbcon = DbConnection.DbConnection();
        if (dbcon != null) {

            try {
                PreparedStatement st = (PreparedStatement) dbcon.prepareStatement("TRUNCATE `course`");

                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.initOwner(PaneNavigator.getMainApp().getPrimaryStage());
                alert.setTitle("You Are About to Delete All instructors Detail!!!!");
                alert.setHeaderText("Are You Sure You Want to Delete ALL");
                alert.setContentText("Click Ok to Delete ALl");
                alert.showAndWait();


                int res = st.executeUpdate();
                JOptionPane.showMessageDialog(null, "Courses cleared succesfully", "Successfull", JOptionPane.INFORMATION_MESSAGE);

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(null,"Error occured while trying to delete instructors details","Error", JOptionPane.ERROR_MESSAGE);
        }
        courseTable.getItems().clear();
        PaneNavigator.getMainApp().getClassesData().clear();
    }
}
