package controller;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javax.swing.JOptionPane;
import model.DbConnection;
import model.Instructor;

public class InstructorsController implements Initializable {
    @FXML
    private TableView<Instructor> instructorTable = new TableView<>();
    @FXML
    private TableColumn<Instructor, Integer> instructorIDCol;
    @FXML
    private TableColumn<Instructor, String> instructorNameCol;
    @FXML
    private TextField newInstructorName;
    int ID;
    public InstructorsController(){

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        System.out.println("initilaize");
        instructorIDCol.setCellValueFactory(new PropertyValueFactory<>("ID"));
        instructorNameCol.setCellValueFactory(new PropertyValueFactory<>("fullname"));
        instructorTable.setItems(PaneNavigator.getMainApp().getInstrutorData());
    }

    @FXML
    private void handleDeleteInstructor() {
        int selectedIndex = instructorTable.getSelectionModel().getSelectedIndex();

        if (selectedIndex >= 0) {
            Connection dbconn = DbConnection.DbConnection();
            String sql = "DELETE FROM `instructors` WHERE ID = ?";

            try {
                PreparedStatement pst = (PreparedStatement) dbconn.prepareStatement(sql);
                pst.setInt(1, selectedIndex);
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.initOwner(PaneNavigator.getMainApp().getPrimaryStage());
                alert.setTitle("You Are About to Delete An Instructor!!!!");
                alert.setHeaderText("Are You Sure You Want to Delete");
                alert.setContentText("Click Ok to Delete");
                pst.execute();

                alert.showAndWait();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex);

            }
            instructorTable.getItems().remove(selectedIndex);
            PaneNavigator.getMainApp().getClassesData().clear();

        } else {
            // Nothing selected.
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initOwner(PaneNavigator.getMainApp().getPrimaryStage());
            alert.setTitle("No Selection");
            alert.setHeaderText("No Instructor Selected");
            alert.setContentText("Please select an instructor in the table.");

            alert.showAndWait();
        }
    }

    private boolean instructorNameIsValid(String instructorName){
        return true;
    }

    @FXML
    private void handleNewInstructor() {
        String instructorName = newInstructorName.getText();

        if(instructorNameIsValid(instructorName)){
            Connection dbcon = DbConnection.DbConnection();
            if (dbcon != null) {

                try {
                    PreparedStatement st = (PreparedStatement) dbcon.prepareStatement("INSERT INTO `instructors` (`ID`, `Name`) VALUES (NULL, ?);");

                    st.setString(1, instructorName);

                    int res = st.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Instructor Added", "Successfull", JOptionPane.INFORMATION_MESSAGE);

                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, ex);
                }
            } else {
                System.out.println("Why All This!!!!!");
            }
            PaneNavigator.getMainApp().getInstrutorData().add(new Instructor(ID,instructorName));
        }
    }

    @FXML
    private void goToClasses(ActionEvent event) {
        System.out.println("goToClasses");
        PaneNavigator.loadPane(PaneNavigator.CLASSES_PANE);
    }

    @FXML
    private void handleClearAll() {
        Connection dbcon = DbConnection.DbConnection();
        if (dbcon != null) {

            try {
                PreparedStatement st = (PreparedStatement) dbcon.prepareStatement("TRUNCATE `instructors`");

                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.initOwner(PaneNavigator.getMainApp().getPrimaryStage());
                alert.setTitle("You Are About to Delete All instructors Detail!!!!");
                alert.setHeaderText("Are You Sure You Want to Delete ALL");
                alert.setContentText("Click Ok to Delete ALl");
                alert.showAndWait();


                int res = st.executeUpdate();
                JOptionPane.showMessageDialog(null, "instructors cleared succesfully", "Successfull", JOptionPane.INFORMATION_MESSAGE);

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(null,"Error occured while trying to delete instructors details","Error", JOptionPane.ERROR_MESSAGE);
        }
        instructorTable.getItems().clear();
        PaneNavigator.getMainApp().getClassesData().clear();
    }
}
