/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import static com.sun.deploy.uitoolkit.ToolkitStore.dispose;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Tab;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import javax.swing.plaf.OptionPaneUI;
import model.DbConnection;

/**
 * FXML Controller class
 *
 * @author Administrator
 */
public class LoginController implements Initializable {

    @FXML
    private Label pane;
    @FXML
    private Label StatusPane;
    @FXML
    private TextField Username;
    @FXML
    private PasswordField Password;
    @FXML
    private Button Login;
    @FXML
    private Button Cancel;
    @FXML
    private Button Reset;
    @FXML
    private Tab SignupTab;
    @FXML
    private Pane SignUpTab;
    @FXML
    private Label Status;
    @FXML
    private TextField txtUsername;
    @FXML
    private TextField txtEmail;
    @FXML
    private PasswordField txtPassword;
    @FXML
    private PasswordField txtConfirmPassword;
    @FXML
    private Button SignupButton;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void OnLoginAction(ActionEvent event) throws Exception {
        Stage homePage = new Stage();
        FXMLLoader loader = new FXMLLoader();
        String tUsername = Username.getText().toString();
        String tPassword = Password.getText().toString();
        if (tUsername.isEmpty() || tPassword.length() < 1) {
            JOptionPane.showMessageDialog(null, "Username or Password field Should not be Empty");
        } else {
            userLogin(tUsername, tPassword);
            Username.setText("");
            Password.setText("");

        }
    }

    @FXML
    private void OnCancelAction(ActionEvent event) {
        Cancel.setCancelButton(true);
        Cancel.setOnAction(e -> {
            System.exit(0);
        });
    }

    @FXML
    private void OnResetAction(ActionEvent event) {
        Username.setText("");
        Password.setText("");
        StatusPane.setText("Your Input has been \n resetted");
    }

    @FXML
    private void OnSignUpLabel(MouseEvent event) {

    }

    @FXML
    private void OnSignupButton(ActionEvent event) {
        Stage homePage = new Stage();
        FXMLLoader loader = new FXMLLoader();
        String Userkey = txtUsername.getText().toString();
        String Emailkey = txtEmail.getText().toString();
        String Passerkey = txtPassword.getText().toString();
        String ConfirmPasserkey = txtConfirmPassword.getText().toString();
        if (Userkey.isEmpty() || Emailkey.isEmpty() || Passerkey.isEmpty() || ConfirmPasserkey.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Fill up the Empty forms!!!!");
        } else if (!(Passerkey.equals(ConfirmPasserkey))) {
            JOptionPane.showMessageDialog(null, "Confirm Password and Password is not equal");
        } else {
            userSignup(Userkey, Emailkey, Passerkey, ConfirmPasserkey);
            txtUsername.setText("");
            txtEmail.setText("");
            txtPassword.setText("");
            txtConfirmPassword.setText("");
        }
    }

    private void userLogin(String tUsername, String tPassword) throws Exception {
        Stage homePage = new Stage();
        FXMLLoader loader = new FXMLLoader();
        Connection dbconn = DbConnection.DbConnection();
        try {
            PreparedStatement st = (PreparedStatement) dbconn.prepareStatement("Select * from sign_up WHERE Username = ? AND Password = ?");

            st.setString(1, tUsername);
            st.setString(2, tPassword);
            ResultSet res = st.executeQuery();
            if (res.next()) {
                try {
                  Parent  root = FXMLLoader.load(getClass().getResource("TimeTable.fxml"));
                    Scene scene = new Scene(root);
                    homePage.setResizable(false);
                    homePage.setTitle("TIME TABLE MANAGEMENT SYSTEM");
                    homePage.setScene(scene);
                    homePage.show();

                } catch (IOException ex) {
                    Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
                }

            } else {
                JOptionPane.showMessageDialog(null, "User or password not found");

            }
        } catch (SQLException ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void userSignup(String Userkey, String Emailkey, String Passerkey, String ConfirmPasserkey) {
        Connection dbconn = DbConnection.DbConnection();
        Stage homePage = new Stage();
        FXMLLoader loader = new FXMLLoader();
        try {
            PreparedStatement st = (PreparedStatement) dbconn.prepareStatement("INSERT INTO sign_up(Username,Email,Password,ConfirmPassword) VALUES(?,?,?,?)");

            st.setString(1, Userkey);
            st.setString(2, Emailkey);
            st.setString(3, Passerkey);
            st.setString(4, ConfirmPasserkey);
            int res = st.executeUpdate();
            JOptionPane.showMessageDialog(null, "Sign up", "Successfull", JOptionPane.INFORMATION_MESSAGE);
            try {
                  Parent  root = FXMLLoader.load(getClass().getResource("TimeTable.fxml"));
                    Scene scene = new Scene(root);
                    homePage.setResizable(false);
                    homePage.setTitle("TIME TABLE MANAGEMENT SYSTEM");
                    homePage.setScene(scene);
                    homePage.show();

                } catch (IOException ex) {
                    Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
                }
        } catch (Exception ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
