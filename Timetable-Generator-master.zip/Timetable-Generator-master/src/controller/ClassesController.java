package controller;

import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import javax.swing.JOptionPane;

import model.Chromosome;
import model.Classes;
import model.Course;
import model.Data;
import model.DbConnection;
import model.Driver;
import model.Instructor;
import model.Room;
import model.StudentsGroup;

public class ClassesController implements Initializable {

    @FXML
    private TableView <Classes> classTable = new TableView<>();
    @FXML
    private TableColumn<model.Classes, String> classIDCol;
    @FXML
    private TableColumn<model.Classes, String> classGroupCol;
    @FXML
    private TableColumn<model.Classes, String> classTypeCol;
    @FXML
    private TableColumn<model.Classes, String> classCourseCol;
    @FXML
    private TableColumn<model.Classes, String> classInstructorCol;
    @FXML
    private TableColumn<model.Classes, String> classRoomCol;

    IntStream in;
    @FXML
    private ChoiceBox<StudentsGroup> newClassGroup;
    @FXML
    private ChoiceBox<String> newClassType;
    @FXML
    private ChoiceBox<Course> newClassCourse;
    @FXML
    private ChoiceBox<Instructor> newClassInstructor;
    @FXML
    private ChoiceBox<Room> newClassRoom;
    private ObservableList<Classes> ClassData = FXCollections.observableArrayList();
    String query = null;
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultset = null;
    public int Id;

    public ClassesController() {

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        System.out.println("initilaize");
        classIDCol.setCellValueFactory(new PropertyValueFactory<>("Id"));
        classGroupCol.setCellValueFactory(new PropertyValueFactory<>("Year"));
        classTypeCol.setCellValueFactory(new PropertyValueFactory<>("ClassType"));
        classCourseCol.setCellValueFactory(new PropertyValueFactory<>("Course"));
        classInstructorCol.setCellValueFactory(new PropertyValueFactory<>("Instructor"));
        classRoomCol.setCellValueFactory(new PropertyValueFactory<>("Classroom"));

        classTable.setItems(PaneNavigator.getMainApp().getClassesData());

        newClassGroup.setItems(PaneNavigator.getMainApp().getGroupData());
        newClassType.getItems().add("Lecture");
        newClassType.getItems().add("Workshop");
        newClassType.getItems().add("Lab");
        newClassCourse.setItems(PaneNavigator.getMainApp().getCourseData());
        newClassInstructor.setItems(PaneNavigator.getMainApp().getInstrutorData());
        newClassRoom.setItems(PaneNavigator.getMainApp().getRoomData());

    }

    @FXML
    private void handleDeleteClass() {
        int selectedIndex = classTable.getSelectionModel().getSelectedIndex();

        if (selectedIndex >= 0) {
            String sql = "DELETE FROM `class` WHERE ID = ?";
            Connection dbconn = DbConnection.DbConnection();
            try {
                PreparedStatement pst = (PreparedStatement) dbconn.prepareStatement(sql);
                pst.setInt(1, selectedIndex);
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.initOwner(PaneNavigator.getMainApp().getPrimaryStage());
                alert.setTitle("You Are About to Delete A Class Detail!!!!");
                alert.setHeaderText("Are You Sure You Want to Delete");
                alert.setContentText("Click Ok to Delete");
                alert.showAndWait();

                pst.execute();

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex);

            }
            classTable.getItems().remove(selectedIndex);
        } else {
            // Nothing selected.
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initOwner(PaneNavigator.getMainApp().getPrimaryStage());
            alert.setTitle("No Selection");
            alert.setHeaderText("No Class Selected");
            alert.setContentText("Please select a class in the table.");

            alert.showAndWait();
        }
    }

    private boolean classesDataIsValid() {
        return true;
    }

    @FXML
    private void handleNewClass() {
        String group = newClassGroup.getValue().toString();
        String type = newClassType.getValue().toString();
        String course = newClassCourse.getValue().toString();
        String instructor = newClassInstructor.getValue().toString();
        String room = newClassRoom.getValue().toString();

        if (classesDataIsValid()) {
            Connection dbcon = DbConnection.DbConnection();
            if (dbcon != null) {

                try {
                    PreparedStatement st = (PreparedStatement) dbcon.prepareStatement("INSERT INTO `class` (`ID`, `Year`, `ClassType`, `Course`, `Instructor`, `Classroom`) VALUES (NULL,?,?,?,?,?)");

                    st.setString(1, group.toString());
                    st.setString(2, type);
                    st.setString(3, course.toString());
                    st.setString(4, instructor.toString());
                    st.setString(5, room.toString());

                    int res = st.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Classes Added successfully", "Successfull", JOptionPane.INFORMATION_MESSAGE);

                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, ex);
                }
            } else {
                System.out.println("Why All This!!!!!");
            }
            PaneNavigator.getMainApp().getClassesData().add(new Classes(Id, group, type, course, instructor, room));
        }
    }

    @FXML
    private void generateTable(ActionEvent event) {
        System.out.println("generateTable");

//        Data.setCourses((Course[]) PaneNavigator.getMainApp().getCourseData().stream().collect(Collectors.toList()).toArray());
        Data.setCourses(PaneNavigator.getMainApp().getCourseData().toArray(new Course[0]));
        Data.setWorkingDays(PaneNavigator.getMainApp().getWorkingDays());
        Data.setDaysPerWeek(Data.workingDays.size());
        Data.setPeriodsPerDay(PaneNavigator.getMainApp().getPeriodsCount());
        Data.setInstructors(PaneNavigator.getMainApp().getInstrutorData().toArray(new Instructor[0]));
        Data.setRooms(PaneNavigator.getMainApp().getRoomData().toArray(new Room[0]));
        Data.setStudentsGroups(PaneNavigator.getMainApp().getGroupData().toArray(new StudentsGroup[0]));
        Data.setClasses(PaneNavigator.getMainApp().getClassesData().toArray(new Classes[0]));
        Chromosome ans = Driver.generateTimeTable();

        if (ans == null) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initOwner(PaneNavigator.getMainApp().getPrimaryStage());
            alert.setTitle("Warning!");
            alert.setHeaderText("No Generated Table");
            alert.setContentText("Can't generate a valid time table.");
            alert.showAndWait();
        } else {
            ArrayList<Classes> generatedTable = new ArrayList<>();
            for (int i = 0; i < ans.chromosomeLength; i++) {

                    int gene = ans.getGene(i);
                    Classes cls = Data.getClassByID(gene);
                    // set day & preriod
                    String day = Data.workingDays.get((i * Data.daysPerWeek / ans.chromosomeLength) % Data.daysPerWeek);
                    int ID = Data.rooms[(i * Data.rooms.length * Data.daysPerWeek / ans.chromosomeLength) % Data.rooms.length].getID();
                    int period = (i % Data.periodsPerDay) + 1;
                    cls.setDay(day);
                    cls.setPeriod(period);
                    cls.setAllowedRoom(Data.getRoomByID(ID));
                    generatedTable.add(cls);
                }
                try {
                    PaneNavigator.getMainApp().setGeneratedTableData(generatedTable);
                    PaneNavigator.loadPane(PaneNavigator.TABULAR_PANE);

                } catch (NullPointerException e) {
                    if (e.getCause().getClass().equals(AssertionError.class)) {
                        // handle your exception  1
                    } else {
                        // handle the rest of the world exception
                    }
                }

            }
        }

        @FXML
        private void handleClearAll () {
            Connection dbcon = DbConnection.DbConnection();
            if (dbcon != null) {

                try {
                    PreparedStatement st = (PreparedStatement) dbcon.prepareStatement("TRUNCATE `class`");

                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.initOwner(PaneNavigator.getMainApp().getPrimaryStage());
                    alert.setTitle("You Are About to Delete All Classes Detail!!!!");
                    alert.setHeaderText("Are You Sure You Want to Delete ALL");
                    alert.setContentText("Click Ok to Delete ALl");
                    alert.showAndWait();


                    int res = st.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Classes cleared succesfully", "Successfull", JOptionPane.INFORMATION_MESSAGE);

                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, ex);
                }
            } else {
                JOptionPane.showMessageDialog(null,"Error occured while trying to delete classes details","Error", JOptionPane.ERROR_MESSAGE);
            }
            classTable.getItems().clear();
        }
    }
