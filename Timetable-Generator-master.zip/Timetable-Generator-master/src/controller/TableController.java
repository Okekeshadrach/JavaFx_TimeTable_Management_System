package controller;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
//import model.Classes;
import model.Classes;

public class TableController implements Initializable {

    @FXML
    private TableView<Classes> generatedTable = new TableView<>();
    @FXML
    private TableColumn<Classes, String> tableDayCol;
    @FXML
    private TableColumn<Classes, String> tableRoomCol;
    @FXML
    private TableColumn<Classes, Integer> tablePeriodCol;
    @FXML
    private TableColumn<Classes, String> tableClassCol;


    public TableController(){

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        System.out.println("initilaize");
        tableDayCol.setCellValueFactory(new PropertyValueFactory<>("day"));
        tableRoomCol.setCellValueFactory(new PropertyValueFactory<>("Room"));
        tablePeriodCol.setCellValueFactory(new PropertyValueFactory<>("period"));
        tableClassCol.setCellValueFactory(new PropertyValueFactory<>("Classroom"));
        generatedTable.setItems(PaneNavigator.getMainApp().getGeneratedTableData());
    }

}
