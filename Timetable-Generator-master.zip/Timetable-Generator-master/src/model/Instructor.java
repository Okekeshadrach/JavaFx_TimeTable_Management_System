package model;

import java.util.ArrayList;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Instructor {
    private int ID;
    private String fullname;

    public Instructor(int ID, String fullname) {
        this.ID = ID;
        this.fullname = fullname;
    }
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }
    public String instructorName() {
        return fullname;
    }

    public int instructorID() {
        return ID;
    }

    @Override
    public String toString() {
        return getFullname();
    }
}
