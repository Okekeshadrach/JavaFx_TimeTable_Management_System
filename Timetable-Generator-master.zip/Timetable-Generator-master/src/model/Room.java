package model;


public class Room {

    private int ID;
    private String name;

    public Room(int ID, String name) {
        this.ID = ID;
        this.name = name;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getID() {
        return ID;
    }

    public String getName() {
        return name;
    }

    public String name() {
        return name;
    }

    public int ID() {
        return ID;
    }

    @Override
    public String toString() {
        return getName();
    }
}