package model;


import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;

public class Chromosome {

    // Time-space slots, one entry represent specific duration in one classroom
    public int chromosomeLength = Data.daysPerWeek * Data.periodsPerDay * Data.rooms.length;
    private final int[] slots = new int[chromosomeLength];
    private final HashMap<Integer, Integer> classesMap = new HashMap<>(); //classID -> assignedSlotIdx
    public double fitnessScore = 0;
    public int ID;
    Chromosome(boolean atRandom){
        Arrays.fill(slots,-1);
        classesMap.clear();
        fitnessScore = 0;
        if(atRandom){
            Random rand = new Random();
            //int roomID = 0;
            for (Classes classe : Data.classes) {
                int slotIdx = rand.nextInt(chromosomeLength);
                int roomID = (((slotIdx*Data.rooms.length*Data.daysPerWeek)/chromosomeLength) % Data.rooms.length);
                while (!classe.isAllowedRoom(roomID) || slots[slotIdx]!=-1) {
                    slotIdx = rand.nextInt(chromosomeLength);
                    roomID = (((slotIdx*Data.rooms.length*Data.daysPerWeek)/chromosomeLength) % Data.rooms.length);
                }
                while(slots[slotIdx]!=-1){
                    slotIdx = rand.nextInt(chromosomeLength);
                }
                int classID = classe.getId();
                slots[slotIdx] = classID;
                classesMap.put(classID, slotIdx);
            }
        }
    }

    public void calcFitness(){
        int qualityScore = 0;
        Iterator<?> it = classesMap.entrySet().iterator();
        while(it.hasNext()){
            Map.Entry pair = (Map.Entry) it.next();
            int classID = (int) pair.getKey();
            int slotIdx = (int) pair.getValue();
            qualityScore+=calculateGeneScore(classID, slotIdx);
        }
        fitnessScore = qualityScore/(3.0*classesMap.size());
    }

    public int calculateGeneScore(int classID, int slotIdx){
        int geneScore = 0;
        ID = Data.rooms[(slotIdx*Data.rooms.length*Data.daysPerWeek/slots.length)%Data.rooms.length].getID();
        if(Data.getClassByID(classID).isAllowedRoom(ID)) {
            geneScore++;
        } else {
        }
        if(instructorIsAvailable(slotIdx)) {
            geneScore++;
        }
        if(groupStudentIsAvailable(slotIdx)) {
            geneScore++;
        }
        return geneScore;
    }

    private boolean instructorIsAvailable(int slotIdx){
        String ins = Data.getClassByID(slots[slotIdx]).getInstructor();
        int instructorClassesCount = 0;
        int k = slotIdx%Data.periodsPerDay;
        int dayID = (slotIdx*Data.daysPerWeek/chromosomeLength)%Data.daysPerWeek;
        k += dayID * (chromosomeLength/Data.daysPerWeek);
        int roomsCount = Data.rooms.length;
        for(int i=0;i<roomsCount;i++,k+=Data.periodsPerDay){
            if(slots[k]==-1){
            }
            else if(Data.getClassByID(slots[k]).getInstructor() == null ? ins == null : Data.getClassByID(slots[k]).getInstructor().equals(ins)){
                instructorClassesCount++;
            }
        }
        return instructorClassesCount == 1;
    }




    private boolean groupStudentIsAvailable(int slotIdx){
        String stdGrp = Data.getClassByID(slots[slotIdx]).getYear();
        int stdGrpClassesCount = 0;
        int k = slotIdx%Data.periodsPerDay;
        int dayID = (slotIdx*Data.daysPerWeek/chromosomeLength)%Data.daysPerWeek;
        k += dayID * (chromosomeLength/Data.daysPerWeek);
        int roomsCount = Data.rooms.length;
        for(int i=0;i<roomsCount;i++,k+=Data.periodsPerDay){
            if(slots[k]==-1){
            }
            else if(Data.getClassByID(slots[k]).getYear() == null ? stdGrp == null : Data.getClassByID(slots[k]).getYear().equals(stdGrp)){
                stdGrpClassesCount++;
            }
        }
        return stdGrpClassesCount == 1;
    }

    @Override
    public String toString() {
        StringBuilder str = new StringBuilder("");
        for(int slot : slots){
            str.append(slot).append(" ");
        }
        classesMap.entrySet().stream().forEach((pair) -> {
            int classID = (int) pair.getKey();
            int slotIdx = (int) pair.getValue();
            StringBuilder append;
            append = str.append(" | ").append(classID).append(" ").append(slotIdx).append(" | ");
        });
        return str.toString();
    }


    public int getGene(int slodIdx){
        return slots[slodIdx];
    }

    public void setGene(int slotIdx, int classID){
        slots[slotIdx] = classID;
        if(classID!=-1) {
            classesMap.put(classID,slotIdx);
        }
    }

    public boolean classHasBeenSet(int classID){
        return classesMap.containsKey(classID);
    }

    public int getSlotIdx(int classID){
        return classesMap.get(classID);
    }
}
