package model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class StudentsGroup {
    private int ID;
    private String name;

    public StudentsGroup(int ID, String name) {
        this.ID = ID;
        this.name = name;
    }



    public int getID() {
        return ID;
    }

    public String getName() {
        return name;
    }

    public String groupName() {
        return name;
    }

    public int groupID() {
        return ID;
    }

    @Override
    public String toString() {
        return  getName();
    }
}
