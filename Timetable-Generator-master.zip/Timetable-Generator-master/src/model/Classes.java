package model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javax.swing.JOptionPane;
import model.Room;

public class Classes {

    int Id;
    String Year, ClassType, Course, Instructor, Classroom;
    private Room allowedRoom;
    private String day = new String("day");
    private int period = 0;

    public Classes(int Id, String Year, String ClassType, String Course, String Instructor, String Classroom) {
        this.Id = Id;
        this.Year = Year;
        this.ClassType = ClassType;
        this.Course = Course;
        this.Instructor = Instructor;
        this.Classroom = Classroom;
    }

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public String getYear() {
        return Year;
    }

    public void setYear(String Year) {
        this.Year = Year;
    }

    public String getClassType() {
        return ClassType;
    }

    public void setClassType(String ClassType) {
        this.ClassType = ClassType;
    }

    public String getCourse() {
        return Course;
    }

    public void setCourse(String Course) {
        this.Course = Course;
    }

    public String getInstructor() {
        return Instructor;
    }

    public void setInstructor(String Instructor) {
        this.Instructor = Instructor;
    }

    public String getClassroom() {
        return Classroom;
    }

    public void setClassroom(String Classroom) {
        this.Classroom = Classroom;
    }

    @Override
    public String toString() {
        String str = "";
        try {
            str = getId() + "_" + Year.toString() + "_" + Course;
        } catch (NullPointerException e) {
            str = "Empty";
        }
        return str;

    }

    public void setAllowedRoom(Room Classroom) {
        this.allowedRoom = Classroom;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public void setPeriod(int period) {
        this.period = period;
    }

    public boolean isAllowedRoom(int Id) {
        try {
            Room ID = allowedRoom;
        } catch (NullPointerException e) {
            allowedRoom.getID();
            JOptionPane.showMessageDialog(null, e);
            return allowedRoom.getID() == Id;
        }
        return true;
    }

    public String Year() {
        return Year;
    }

    public String ClassType() {
        return ClassType;
    }

    public String Course() {
        return Course;
    }

    public String classInstructor() {
        return Instructor;
    }

    public String classroom() {
        return allowedRoom.name();
    }
}
