package view;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import controller.MainController;
import controller.PaneNavigator;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import model.Classes;
import model.Course;
import model.DbConnection;
import model.Instructor;
import model.Room;
import model.StudentsGroup;

public class App extends Application {

    private Stage primaryStage;
    private ObservableList<Room> RoomData = FXCollections.observableArrayList();
    private ObservableList<StudentsGroup> GroupData = FXCollections.observableArrayList();
    private ObservableList<Course> CourseData = FXCollections.observableArrayList();
    private ObservableList<Instructor> InstructorData = FXCollections.observableArrayList();
    private ObservableList<Classes> ClassesData = FXCollections.observableArrayList();
    private HashMap<String, Boolean> workingDays = new HashMap<>();
    private ObservableList<Classes> generatedTableData = FXCollections.observableArrayList();
    private int periodsCount = 4;
    String query = null;
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultset = null;

    @Override
    public void start(Stage stage) throws Exception {
        primaryStage = stage;
        primaryStage.setTitle("Time Table Management System");
        primaryStage.setResizable(false);
        primaryStage.getIcons().add(new Image("file:resources/images/logo.png"));
        primaryStage.setScene(createScene(loadMainPane()));
        primaryStage.show();
        initialize();
    }

    public Stage getPrimaryStage() {
        return primaryStage;
    }

    public void initialize() {
        JOptionPane.showMessageDialog(null, "Loading Tables", "Loading Modules", JOptionPane.INFORMATION_MESSAGE);

        try {
            connection = DbConnection.DbConnection();
            RoomData.clear();

            String ery = "SELECT * FROM `classroom`";
            preparedStatement = DbConnection.conn.prepareStatement(ery);
            JOptionPane.showMessageDialog(null, "Loading Classroom data", "Loading Modules", JOptionPane.INFORMATION_MESSAGE);
            resultset = preparedStatement.executeQuery(ery);

            while (resultset.next()) {
                RoomData.add(new Room(
                        resultset.getInt("ID"),
                        resultset.getString("ClassRoom_Name")
                ));
            }
        } catch (SQLException ex) {
            Logger.getLogger(DbConnection.class.getName()).log(Level.SEVERE, null, ex);
        }
//        Year Table Begins here




        try {
            connection = DbConnection.DbConnection();
            GroupData.clear();

            String que = "SELECT * FROM `year`";
            preparedStatement = DbConnection.conn.prepareStatement(que);
            JOptionPane.showMessageDialog(null, "Loading Year Data", "Loading Modules", JOptionPane.INFORMATION_MESSAGE);
            resultset = preparedStatement.executeQuery(que);

            while (resultset.next()) {
                GroupData.add(new StudentsGroup(
                        resultset.getInt("ID"),
                        resultset.getString("Year")
                ));
            }
        } catch (SQLException ex) {
            Logger.getLogger(DbConnection.class.getName()).log(Level.SEVERE, null, ex);
        }
//        Year Table ends here



//         Course table begins here
        try {
            connection = DbConnection.DbConnection();
            CourseData.clear();

            String uery = "SELECT * FROM `course`";
            preparedStatement = DbConnection.conn.prepareStatement(uery);
            JOptionPane.showMessageDialog(null, "Loading Course data", "Loading Modules", JOptionPane.INFORMATION_MESSAGE);
            resultset = preparedStatement.executeQuery(uery);

            while (resultset.next()) {
                CourseData.add(new Course(
                        resultset.getString("CourseCode"),
                        resultset.getString("CourseName")
                ));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }






        try {
            connection = DbConnection.DbConnection();
            InstructorData.clear();

            String quer = "SELECT * FROM `instructors`";
            preparedStatement = DbConnection.conn.prepareStatement(quer);
            JOptionPane.showMessageDialog(null, "Loading Instructor data", "Loading Modules", JOptionPane.INFORMATION_MESSAGE);
            resultset = preparedStatement.executeQuery(quer);

            while (resultset.next()) {
                InstructorData.add(new Instructor(
                        resultset.getInt("ID"),
                        resultset.getString("Name")
                ));
            }
        } catch (SQLException ex) {
            Logger.getLogger(DbConnection.class.getName()).log(Level.SEVERE, null, ex);
        }



        try {
            connection = DbConnection.DbConnection();
            ClassesData.clear();

            String sql;
            sql = "SELECT * FROM `class`";
            preparedStatement = DbConnection.conn.prepareStatement(sql);
            JOptionPane.showMessageDialog(null, "Loading Classes data", "Loading Modules", JOptionPane.INFORMATION_MESSAGE);
            resultset = preparedStatement.executeQuery(sql);

            while (resultset.next()) {
                ClassesData.add(new Classes(
                        resultset.getInt("ID"),
                        resultset.getString("Year"),
                        resultset.getString("ClassType"),
                        resultset.getString("Course"),
                        resultset.getString("Instructor"),
                        resultset.getString("Classroom")
                ));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }



        workingDays.put("monday", true);
        workingDays.put("tuesday", true);
        workingDays.put("wednesday", true);
        workingDays.put("thursday", true);
        workingDays.put("friday", true);
        workingDays.put("saturday", false);
    }

    private Pane loadMainPane() throws IOException {
        FXMLLoader loader = new FXMLLoader(new URL("file:resources/fxml/" + PaneNavigator.MAIN_PANE));
        //loader.setLocation(new URL("file:resources/fxml/" + PaneNavigator.MAIN_PANE));
        //Pane mainPane = loader.load();
        Pane mainPane = loader.load();
        MainController mainController = loader.getController();
        PaneNavigator.setMainApp(this);
        PaneNavigator.setMainController(mainController);
        PaneNavigator.loadPane(PaneNavigator.START_PANE);

        return mainPane;
    }

    private Scene createScene(Pane mainPane) {
        Scene scene = new Scene(mainPane);
        //new URL("file:resources/style/tab.css)
        File f = new File("resources/style/tab.css");
        scene.getStylesheets().add("file:///" + f.getAbsolutePath().replace("\\", "/"));
        //scene.getStylesheets().add(this.getClass().getResource("/resources/style/tab.css").toExternalForm());
        f = new File("resources/style/style.css");
        scene.getStylesheets().add("file:///" + f.getAbsolutePath().replace("\\", "/"));
        return scene;
    }


    public static void main(String[] args) {
        launch();
    }

    public ObservableList<Room> getRoomData() {
        return RoomData;
    }

    public ObservableList<StudentsGroup> getGroupData() {
        return GroupData;
    }

    public ObservableList<Course> getCourseData() {
        return CourseData;
    }

    public ObservableList<Instructor> getInstrutorData() {
        return InstructorData;
    }

    public ObservableList<Classes> getClassesData() {
        return ClassesData;
    }

    public HashMap<String,Boolean> getWorkingDays() {
        return workingDays;
    }

    public int getPeriodsCount() {
        return periodsCount;
    }

    public void setPeriodsCount(int periodsCount) {
        this.periodsCount = periodsCount;
    }

    public ObservableList<Classes> getGeneratedTableData() {
        return generatedTableData;
    }

    public void setGeneratedTableData(ArrayList<Classes> generatedtable){
        generatedTableData.clear();
        generatedTableData.addAll(generatedtable);
    }
}