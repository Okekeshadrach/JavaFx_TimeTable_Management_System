-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 23, 2021 at 12:47 PM
-- Server version: 8.0.21
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `time-table-generator`
--

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

DROP TABLE IF EXISTS `class`;
CREATE TABLE IF NOT EXISTS `class` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Year` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `ClassType` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Course` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Instructor` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Classroom` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`ID`, `Year`, `ClassType`, `Course`, `Instructor`, `Classroom`) VALUES
(1, 'Cit Yr2', 'Lab', 'Com222 Python Programming', 'Master. Eze Emmanuel', 'CIT NEW LAB'),
(2, 'Elect Yr2', 'Workshop', 'Com222 Python Programming', 'Master. Eze Emmanuel', 'Electrical workshop');

-- --------------------------------------------------------

--
-- Table structure for table `classroom`
--

DROP TABLE IF EXISTS `classroom`;
CREATE TABLE IF NOT EXISTS `classroom` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `ClassRoom_Name` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ClassRoom_Name` (`ClassRoom_Name`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `classroom`
--

INSERT INTO `classroom` (`ID`, `ClassRoom_Name`) VALUES
(1, 'Cit new lab'),
(2, 'Cit lab'),
(3, 'Mech 1 classroom'),
(4, 'Elect 1 classroom'),
(5, 'Elect 2 classroom'),
(6, 'Mech 2 classroom'),
(7, 'Cit 2 classroom'),
(8, 'Cit 1 classroom'),
(9, 'Electrical workshop'),
(10, 'Mechanical workshop'),
(11, 'Phy/Chem lab'),
(12, 'Solar lab'),
(13, 'Library');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
CREATE TABLE IF NOT EXISTS `course` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `CourseCode` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `CourseName` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `CourseName` (`CourseName`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`ID`, `CourseCode`, `CourseName`) VALUES
(1, 'COM 222', 'PYTHON PROGRAMMING'),
(2, 'COM 215', 'DESIGN THEORY'),
(3, 'EEC 227', 'PROJECT'),
(4, 'EEC 217', 'ELECTRICAL WORKSHOP PRACTICE'),
(5, 'EEC 201', 'ELECTRONICS II'),
(6, 'EEC 216', 'PROGRAMMABLE LOGIC CONTROL (PLC)'),
(7, 'EEC 202', 'RENEWABLE ENERGIES (SOLAR SYSTEM)'),
(8, 'EEC 212', 'ELECTRICAL MACHINE II & WINDING'),
(12, 'EEC 112', 'BUILDING INSTALLATION'),
(10, 'EEC 112', 'WORKSHOP PRACTICE'),
(11, 'EEC 102', 'ELECTRICAL POWER');

-- --------------------------------------------------------

--
-- Table structure for table `instructors`
--

DROP TABLE IF EXISTS `instructors`;
CREATE TABLE IF NOT EXISTS `instructors` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Name` (`Name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sign_up`
--

DROP TABLE IF EXISTS `sign_up`;
CREATE TABLE IF NOT EXISTS `sign_up` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Username` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Email` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Password` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `ConfirmPassword` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Confirm Password` (`Password`,`ConfirmPassword`),
  KEY `E-mail` (`Email`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='//Login and Signup table';

--
-- Dumping data for table `sign_up`
--

INSERT INTO `sign_up` (`ID`, `Username`, `Email`, `Password`, `ConfirmPassword`) VALUES
(1, 'Okeke', '@Okeke', 'Okeke', 'Okeke'),
(2, 'swaggy', 'ikechukwujohnpaul55@gmail.com', 'mmmmmmmmmmmm', 'mmmmmmmmmmmm'),
(3, 'lee', '@gmail.com', 'Gigi', 'Gigi');

-- --------------------------------------------------------

--
-- Table structure for table `time table`
--

DROP TABLE IF EXISTS `time table`;
CREATE TABLE IF NOT EXISTS `time table` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Day` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Classroom` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Period` int NOT NULL,
  `Class` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `year`
--

DROP TABLE IF EXISTS `year`;
CREATE TABLE IF NOT EXISTS `year` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Year` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID` (`ID`,`Year`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `year`
--

INSERT INTO `year` (`ID`, `Year`) VALUES
(1, 'CIT YEAR 1'),
(2, 'CIT YEAR 2'),
(3, 'MECH YEAR 2'),
(4, 'MECH YEAR 1'),
(5, 'ELECT YEAR 1'),
(6, 'ELECT YEAR 2');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
